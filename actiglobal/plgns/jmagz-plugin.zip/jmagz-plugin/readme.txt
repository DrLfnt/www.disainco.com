1.0.0
- Initial Release

1.0.1
- Fix compatibility with older php version 5.3

1.0.2
- Fix compatibility with older php version 5.2

1.0.3
- fix side ads size
- add option to have option on front page query
- unique content group for landing page

1.0.4
- Translate some word that not yet translated
- Fix ads background that close top heading background
- Add additional ad type (shortcode)
- Twitter share to use title as first word instead "Check this awesome article"
- Update visual composer to version 4.4.3
- Update WooCommerce compatibility to version 2.3.7
- Fix HTML escape on WooCommerce
- Fix Landing Slider bug on mobile
- add VK share on single page
- Fix ads size to use only horizontal ads on google ads
- Fix mobile navigation that still using desktop logo
- Fix PO location and name on jmagz-plugin, now can easily change using poedit or CodeStyling Localization

1.0.5
- fix related post wording that prevent YARPP plugin to work
- add YARPP plugin into child themes so it can work also on child theme
- Pull first image if none of attached image used
- Update TGM Plugin class
- Update WooCommerce compatibility to version 2.3.8
- Update JPlugin to version 1.0.4 to improve Jmagz Importer
- Add Review on RSS Feed