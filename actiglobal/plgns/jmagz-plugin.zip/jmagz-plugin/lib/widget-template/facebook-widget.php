<div class="blog-fb-likebox">
    <div class="fb-like-box" data-colorscheme="dark" data-href="<?php echo $facebookurl; ?>" data-width="292" data-height="300" data-show-faces="true" data-header="false" data-stream="false" data-show-border="true"></div>
</div>
<script>
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=416961721700378&version=v2.0";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>